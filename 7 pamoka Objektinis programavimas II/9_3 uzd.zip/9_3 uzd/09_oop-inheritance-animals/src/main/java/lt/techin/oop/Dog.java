package lt.techin.oop;

public class Dog extends Animal{

    public Dog(String color, int numberOfPaws, boolean hasFur) {
        super(color, numberOfPaws, hasFur);
    }
}
