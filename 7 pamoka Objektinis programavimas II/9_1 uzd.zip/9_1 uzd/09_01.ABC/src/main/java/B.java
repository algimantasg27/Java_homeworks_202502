public class B extends A{

    public void b() {
        System.out.println("B");
    }
}
