

public class Division {

    public static void main(String[] args) {
        division(3, 5);
    }

    public static void division (int numerator, int denominator) {
        System.out.println((double)numerator / denominator);
    }
}
