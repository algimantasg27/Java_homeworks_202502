
import java.util.Scanner;

public class CountingToHundred {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int inputNumber = Integer.valueOf(scanner.nextLine());

        for (int i = inputNumber; i <= 100 ; i++) {
            System.out.println(i);
        }
    }
}
